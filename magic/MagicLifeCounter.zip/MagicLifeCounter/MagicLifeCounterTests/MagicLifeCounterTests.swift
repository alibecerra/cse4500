//
//  MagicLifeCounterTests.swift
//  MagicLifeCounterTests
//
//  Created by Ali Becerra on 4/27/25.
//

import Testing
@testable import MagicLifeCounter

struct MagicLifeCounterTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
