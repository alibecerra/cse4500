//
//  ViewController.swift
//  MagicLifeCounter
//
//  Created by Ali Becerra on 4/27/25.
//

import UIKit

class ViewController: UIViewController {
    
    var enemyLifeTotal = 20;
    
    var myLIfeTotal = 20;
    
    @IBOutlet weak var enemyLabel: UILabel!
    
    @IBOutlet weak var myLabel: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func redPlusTap(_ sender: Any) {
        enemyLifeTotal += 1
        //print(enemyLifeTotal)
        enemyLabel.text = "\(enemyLifeTotal)"
    }
    
    
    @IBAction func redMinusTap(_ sender: Any) {
        enemyLifeTotal -= 1
       // printContent(enemyLifeTotal)
        enemyLabel.text = "\(enemyLifeTotal)"
    }
    
    @IBAction func bluePlusTap(_ sender: Any) {
        myLIfeTotal += 1
       // printContent(myLIfeTotal)\
        myLabel.text = "\(myLIfeTotal)"
    }
    
    
    @IBAction func blueMinusTap(_ sender: Any) {
        myLIfeTotal -= 1
       // printContent(myLIfeTotal)
        myLabel.text = "\(myLIfeTotal)"
    }
    
}

