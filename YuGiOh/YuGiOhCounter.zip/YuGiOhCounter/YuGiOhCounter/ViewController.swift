//
//  ViewController.swift
//  YuGiOhCounter
//
//  Created by Ali Becerra on 4/27/25.
//

import UIKit

class ViewController: UIViewController {
    
    
    var enemyLifePoints = 8000
    var myLifePoints = 8000
    
    
    @IBOutlet weak var myLPLabel: UILabel!
    @IBOutlet weak var enemyLPLabel: UILabel!
    @IBOutlet weak var enemyStatus: UILabel!
    
    @IBOutlet weak var myStatus: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    func updateEnemyLP(diff: Int)
    {
        enemyLifePoints += diff
        enemyLPLabel.text = "\(enemyLifePoints)"
    }
    
    func updateMyLP(diff: Int)
    {
        myLifePoints += diff
        myLPLabel.text = "\(myLifePoints)"
    }
    
    func checkEnemyStatus()
    {
        if enemyLifePoints <= 0
        {
            enemyStatus.text = "You Lose! Try again!"
            myStatus.text = "You Win!"
        }
        else
        {
            enemyStatus.text = ""
            myStatus.text = ""
        }
    }
    
    func checkMyStatus()
    {
        if myLifePoints <= 0
        {
            enemyStatus.text = "You Win!"
            myStatus.text = "You Lose! Try again!"
        }
        else
        {
            enemyStatus.text = ""
            myStatus.text = ""
        }
    }
    
    @IBAction func redPlus10(_ sender: Any) {
        updateEnemyLP(diff: 10)
    }
    
    @IBAction func redPlus50(_ sender: Any) {
        updateEnemyLP(diff: 50)
    }
    
    @IBAction func redPlus100(_ sender: Any) {
        updateEnemyLP(diff: 100)
    }
    
    @IBAction func redPlus1000(_ sender: Any) {
        updateEnemyLP(diff: 1000)
    }
    
    
    @IBAction func redMinus10(_ sender: Any) {
        updateEnemyLP(diff: -10)
        checkEnemyStatus()
    }
    
    @IBAction func redMinus50(_ sender: Any) {
        updateEnemyLP(diff: -50)
        checkEnemyStatus()
    }
    
    @IBAction func redMinus100(_ sender: Any) {
        updateEnemyLP(diff: -100)
        checkEnemyStatus( )
    }
    
    @IBAction func redMinus1000(_ sender: Any) {
        updateEnemyLP(diff: -1000)
        checkEnemyStatus( )
    }
    
    
    @IBAction func bluePlus10(_ sender: Any) {
        updateMyLP(diff: 10)
        
    }
    
    @IBAction func bluePlus50(_ sender: Any) {
        updateMyLP(diff: 50)
    }
    
    @IBAction func bluePlus100(_ sender: Any) {
        updateMyLP(diff: 100)
    }
    
    
    @IBAction func bluePlus1000(_ sender: Any) {
        updateMyLP(diff: 1000)
    }
    
    @IBAction func blueMinus10(_ sender: Any) {
        updateMyLP(diff: -10)
        checkMyStatus()
    }
    
    @IBAction func blueMinus50(_ sender: Any) {
        updateMyLP(diff: -50)
        checkMyStatus()
    }
    
    @IBAction func blueMinus100(_ sender: Any) {
        updateMyLP(diff: -100)
        checkMyStatus( )
    }
    
    @IBAction func blueMinus1000(_ sender: Any) {
        updateMyLP(diff: -1000)
        checkMyStatus( )
    }
    
}

